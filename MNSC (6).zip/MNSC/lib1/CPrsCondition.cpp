#include "pch.h"
#include "CPrsNode.h"

// && -> 2010.3.28
// 	if (... && (...||... )) �͂Q�d�J�b�R�͖��Ή�


class CSubExpression
{
	public:
		CSubExpression(std::shared_ptr<CPrsExpression> p, int Token=noToken) { expression = p; token = Token; }
		CSubExpression(const CSubExpression& src);
		~CSubExpression() { expression = nullptr; }
	public:
		std::shared_ptr<CPrsExpression> expression;
		int					token;
};
CSubExpression::CSubExpression(const CSubExpression& src)
{	
	token = src.token;
	expression = src.expression;
}



//////////////////////////////////////////////////////////////////////////////////////////////////
CPrsCondition::CPrsCondition(CPrsSymbol& sym) :CPrsNode(sym), m_bool(FALSE)
{

}
CPrsCondition::CPrsCondition(const CPrsCondition& src) :CPrsNode(src.m_Symbol)
{
	m_bool = src.m_bool;
	//for(auto& it : src.m_Ls )
	//	m_Ls.push_back(std::make_shared<CSubExpression>(*it));

	m_Ls = src.m_Ls;
}
CPrsCondition::~CPrsCondition()
{
	Flush();
}
void CPrsCondition::Flush()
{
	m_Ls.clear();
}
//void CPrsCondition::Parse()
//{
//	ParseBase();
//
//	SToken st = getSymbol();
//
//	while (st.Token == ANDAND || st.Token == OROR)
//	{
//		SToken st1 = getNewSymbol();
//
//		ParseBase();
//
//		m_Ls.push_back( std::make_shared<CSubExpression>(nullptr, st.Token));
//
//		st = getSymbol();
//	}
//}


void CPrsCondition::Parse()
{
	KConds();
}
void CPrsCondition::KConds()
{
	KCondTerm();
	KCond2();
}
void CPrsCondition::KCondTerm()
{
	KCondFactor();
	KCondTerm1();
}
void CPrsCondition::KCond2()
{
	SToken st = getSymbol();
	while( st.Token == OROR )
	{
		SToken st1 = getNewSymbol();
		
		KCondTerm();
		
		m_Ls.push_back(std::make_shared<CSubExpression>(nullptr, st.Token ));
		st = getSymbol();
	}
}

void CPrsCondition::KCondTerm1()
{
	SToken st = getSymbol();
	while( st.Token == ANDAND )
	{
		SToken st1 = getNewSymbol();
		
		KCondFactor();
		
		m_Ls.push_back(std::make_shared<CSubExpression>(nullptr, st.Token ));
		st = getSymbol();
	}
}
void CPrsCondition::KCondFactor()
{	
	SToken st = getSymbol();
	if ( st.Token == lParen )
	{
		SToken st1 = getNewSymbol();
		KConds();
	}
	else
		KCond();
}
void CPrsCondition::KCond()
{
	ParseBase();
}



//////////////////////////////////////////////////////////////////////////////////////////////

void CPrsCondition::ParseBase()
{
	auto expression = std::make_shared<CPrsExpression>(m_Symbol);
	expression->Parse();

	m_Ls.push_back(std::make_shared<CSubExpression>(expression));

	SToken st = getSymbol();

	if (st.Token == Equal || st.Token == notEqual || st.Token == LessEqual
		|| st.Token == Less || st.Token == Greater || st.Token == GreaterEqual)
	{
		int TokenMethod = st.Token;
		m_Ls.push_back(std::make_shared<CSubExpression>(nullptr, TokenMethod));

		getNewSymbol();
		expression = std::make_shared<CPrsExpression>(m_Symbol);
		expression->Parse();

		m_Ls.push_back(std::make_shared<CSubExpression>(expression));

		st = getSymbol();
	}
	else
		THROW(L"'==,<,>' and so expected");
}

BOOL CPrsCondition::enableProcess()
{
	return m_bool;
}

struct SMethod
{
	SMethod():Token(0){}
	FVariant value;
	int		Token;
};

void CPrsCondition::Generate(stackGntInfo& stinfo)
{
	SMethod		sm;
	int connds = -1;
	BOOL bl;

	std::stack<BOOL> mst;

	for(auto& subexpression : m_Ls)
	{
		FVariant value;

		if (subexpression->expression)
		{
			subexpression->expression->Generate(stinfo);
			value = subexpression->expression->getValue();
		}


		switch (subexpression->token)
		{
			case ANDAND:
			{
				BOOL b1 = mst.top(); mst.pop();
				BOOL b2 = mst.top(); mst.pop();


				mst.push( (BOOL)(b1 && b2));
			}
			break;
			case OROR:
			{
				BOOL b1 = mst.top(); mst.pop();
				BOOL b2 = mst.top(); mst.pop();

				mst.push((BOOL)(b1 || b2));
			}
			break;

			case Equal:
			case notEqual:
			case LessEqual:
			case GreaterEqual:
			case Less:
			case Greater:
				sm.Token = subexpression->token;
				break;
			case noToken:
			{
				switch (sm.Token)
				{
				case Equal:
					bl = (sm.value == value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case notEqual:
					bl = (sm.value != value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case LessEqual:
					bl = (sm.value <= value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case GreaterEqual:
					bl = (sm.value >= value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case Less:
					bl = (sm.value < value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case Greater:
					bl = (sm.value > value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case noToken:
					sm.value = value;
					break;
				}
			}
			break;
		}		
	}


	_ASSERT(mst.size() != 0);

	m_bool = mst.top();


}

