#include "pch.h"
#include "FVariant.h"
#include "FVariantFunction.h"

// VARIANT VarInvoke(wstring funcnm, bool* bUpdate, VARIANT* v, int vcnt)


#pragma region STATICFUNC

static VARIANT length(const VARIANT v, const VARIANT, const VARIANT, const VARIANT)
{
	if ( v.vt == VT_BSTR )
	{
		auto len = ::SysStringLen(v.bstrVal);
		FVariant v((long long)len);
		return v.ToVARIANT();
	}
	return FVariant(0).ToVARIANT(); 
}
static VARIANT toUpper(const VARIANT v, const VARIANT, const VARIANT, const VARIANT)
{
	if (v.vt == VT_BSTR)
	{
		BSTR s = ::SysAllocString(v.bstrVal);
		auto len = ::SysStringLen(s);

		const int off = 'A' - 'a';
		for (UINT i = 0; i < len; i++)
		{
			auto& ch = s[i];

			if ('a' <= ch && ch <= 'z')
				ch = ch + off;
		}
		
		return FVariant(s).ToVARIANT();
	}
	return FVariant(L"").ToVARIANT();
}
static VARIANT toLower(const VARIANT v, const VARIANT, const VARIANT, const VARIANT)
{
	if (v.vt == VT_BSTR)
	{
		BSTR s = ::SysAllocString(v.bstrVal);
		auto len = ::SysStringLen(s);

		const int off = 'A' - 'a';
		for (UINT i = 0; i < len; i++)
		{
			auto& ch = s[i];

			if ('a' <= ch && ch <= 'z')
				ch = ch - off;
		}

		return FVariant(s).ToVARIANT();
	}
	return FVariant(L"").ToVARIANT();
}


static VARIANT substr(const VARIANT target, const VARIANT spos, const VARIANT len, const VARIANT)
{
	if (target.vt == VT_BSTR)
	{		
		BSTR s = target.bstrVal;
		UINT ispos = (UINT)spos.llVal;
		UINT iepos = min(::SysStringLen(s), ((UINT)len.llVal + ispos));

		auto len = iepos-ispos;

		std::vector<WCHAR> cb(len+1);
		memcpy( &cb[0], s+ispos, sizeof(WCHAR)*len);
		cb[len]=0;
					
		FVariant ret;
		ret.setBSTR(&cb[0]);

		return ret.ToVARIANT();		
	}
	return FVariant(L"").ToVARIANT();
}
static VARIANT toNumber(const VARIANT target, const VARIANT , const VARIANT , const VARIANT)
{
	if (target.vt == VT_BSTR)
	{
		BSTR s = target.bstrVal;
		FVariant ret(_wtoi64(s));
		return ret.ToVARIANT();
	}
	return FVariant((__int64)0).ToVARIANT();
}
static VARIANT toLeft(const VARIANT target, const VARIANT len, const VARIANT empty, const VARIANT)
{
	return substr(target, FVariant((long long)0).ToVARIANT(), len, empty);
}
static VARIANT toStr(const VARIANT target, const VARIANT , const VARIANT , const VARIANT)
{
	FVariant ret = target;
	ret.toStr();
	//return ret;	

	VARIANT vret;
	::VariantInit(&vret);
	ret.ToCopy(&vret);
	return vret;


}
static VARIANT getSquare(const VARIANT target, const VARIANT pos, const VARIANT empty, const VARIANT)
{
	FVariant ret;
	if (target.vt == VT_BSTR)
	{
		ret = substr(target,pos,FVariant(1).ToVARIANT(), empty);
	}

	return ret.ToVARIANT();

}
#pragma endregion

void VarFunctionInit(std::map<wstring, VARIANTFUNC>& map)
{
	map[L"length"] = length;
	map[L"toUpper"] = toUpper;
	map[L"toLower"] = toLower;
	map[L"substr"] = substr;
	map[L"toNumber"] = toNumber;
	map[L"left"] = toLeft;
	map[L"str"] = toStr;
	map[L"[]"] = getSquare;
}