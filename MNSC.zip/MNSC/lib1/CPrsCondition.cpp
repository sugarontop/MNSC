#include "pch.h"
#include "CPrsNode.h"

class CSubExpression
{
	public:
		CSubExpression(std::shared_ptr<CPrsExpression> p, int Token=noToken) { expression = p; token = Token; }
		CSubExpression(const CSubExpression& src);
		~CSubExpression() { expression = nullptr; }
	public:
		std::shared_ptr<CPrsExpression> expression;
		int					token;
};
CSubExpression::CSubExpression(const CSubExpression& src)
{	
	token = src.token;
	expression = src.expression;
}



//////////////////////////////////////////////////////////////////////////////////////////////////
CPrsCondition::CPrsCondition(CPrsSymbol& sym) :CPrsNode(sym), m_bool(false)
{

}
CPrsCondition::CPrsCondition(const CPrsCondition& src) :CPrsNode(src.m_Symbol)
{
	m_bool = src.m_bool;
	m_Ls = src.m_Ls;
	//expression_ = src.expression_;
}
CPrsCondition::~CPrsCondition()
{
	Flush();
}
void CPrsCondition::Flush()
{
	m_Ls.clear();
}


//void CPrsCondition::Parse()
//{
//	ParseBase();
//
//	SToken st = getSymbol();
//
//	while (st.Token == ANDAND || st.Token == OROR)
//	{
//		SToken st1 = getNewSymbol();
//
//		ParseBase();
//
//		m_Ls.push_back( std::make_shared<CSubExpression>(nullptr, st.Token));
//
//		st = getSymbol();
//	}
//}


void CPrsCondition::Parse()
{
	KConds();
}

void CPrsCondition::Generate(stackGntInfo& stinfo)
{
	Generate2(stinfo);
}


//void CPrsCondition::Parse()
//{
//	KConds();
//}
void CPrsCondition::KConds()
{
	KCondTerm();
	KCond2();
}
void CPrsCondition::KCondTerm()
{
	KCondFactor();
	KCondTerm1();
}
void CPrsCondition::KCond2()
{
	SToken st = getSymbol();
	while( st.Token == OROR )
	{
		SToken st1 = getNewSymbol();
		
		KCondTerm();
		
		m_Ls.push_back(std::make_shared<CSubExpression>(nullptr, st.Token ));
		st = getSymbol();
	}
}

void CPrsCondition::KCondTerm1()
{
	SToken st = getSymbol();
	while( st.Token == ANDAND )
	{
		SToken st1 = getNewSymbol();
		
		KCondFactor();
		
		m_Ls.push_back(std::make_shared<CSubExpression>(nullptr, st.Token ));
		st = getSymbol();
	}
}
void CPrsCondition::KCondFactor()
{	
	SToken st = getSymbol();
	if ( st.Token == lParen )
	{
		SToken st1 = getNewSymbol();
		KConds();
	}
	else
		KCond();
}
void CPrsCondition::KCond()
{
	ParseBase();
}



//////////////////////////////////////////////////////////////////////////////////////////////

//void CPrsCondition::ParseBase()
//{
//	auto expression = std::make_shared<CCNDPrsExpression>(m_Symbol);
//	expression->Parse();
//
//	m_Ls.push_back(std::make_shared<CSubExpression>(expression));
//
//	SToken st = getSymbol();
//
//	while (st.Token == Equal || st.Token == notEqual || st.Token == LessEqual
//		|| st.Token == Less || st.Token == Greater || st.Token == GreaterEqual)
//	{
//		int TokenMethod = st.Token;
//		m_Ls.push_back(std::make_shared<CSubExpression>(nullptr, TokenMethod));
//
//		getNewSymbol();
//		expression = std::make_shared<CCNDPrsExpression>(m_Symbol);
//		expression->Parse();
//
//		m_Ls.push_back(std::make_shared<CSubExpression>(expression));
//
//		st = getSymbol();
//	}
//	
//}



void CPrsCondition::ParseBase()
{
	auto expression = std::make_shared<CPrsExpression>(m_Symbol);
	expression->Parse();

	m_Ls.push_back(std::make_shared<CSubExpression>(expression));

	SToken st = getSymbol();

	while (st.Token == Equal || st.Token == notEqual || st.Token == LessEqual
		|| st.Token == Less || st.Token == Greater || st.Token == GreaterEqual)
	{
		int TokenMethod = st.Token;
		m_Ls.push_back(std::make_shared<CSubExpression>(nullptr, TokenMethod));

		getNewSymbol();
		expression = std::make_shared<CPrsExpression>(m_Symbol);
		expression->Parse();

		m_Ls.push_back(std::make_shared<CSubExpression>(expression));

		st = getSymbol();
	}	
}

bool CPrsCondition::enableProcess()
{
	return m_bool;
}

struct SMethod
{
	SMethod():Token(0){}
	FVariant value;
	int		Token;
};

void CPrsCondition::Generate2(stackGntInfo& stinfo)
{
	SMethod		sm;
	int connds = -1;
	BOOL bl;

	std::stack<bool> mst;

	for(auto& subexpression : m_Ls)
	{
		FVariant value;

		if (subexpression->expression)
		{
			subexpression->expression->Generate(stinfo);
			value = subexpression->expression->getValue();
		}


		switch (subexpression->token)
		{
			case ANDAND:
			{
				bool b1 = mst.top(); mst.pop();
				bool b2 = mst.top(); mst.pop();


				mst.push(b1 && b2);
			}
			break;
			case OROR:
			{
				bool b1 = mst.top(); mst.pop();
				bool b2 = mst.top(); mst.pop();

				mst.push(b1 || b2);
			}
			break;

			case Equal:
			case notEqual:
			case LessEqual:
			case GreaterEqual:
			case Less:
			case Greater:
				sm.Token = subexpression->token;
				break;
			case noToken:
			{
				switch (sm.Token)
				{
				case Equal:
					bl = (sm.value == value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case notEqual:
					bl = (sm.value != value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case LessEqual:
					bl = (sm.value <= value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case GreaterEqual:
					bl = (sm.value >= value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case Less:
					bl = (sm.value < value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case Greater:
					bl = (sm.value > value);
					mst.push(bl);
					sm.Token = noToken;
					break;
				case noToken:
					sm.value = value;
					break;
				}
			}
			break;
		}		
	}


	_ASSERT(mst.size() != 0);

	m_bool = mst.top();


}

//////////////////////////////////////////////////////////////////////////////////////////////////
CPrsConditionEx::CPrsConditionEx(CPrsSymbol& sym) :CPrsNode(sym), m_bool(false)
{

}
CPrsConditionEx::CPrsConditionEx(const CPrsConditionEx& src) :CPrsNode(src.m_Symbol)
{
	m_bool = src.m_bool;
	m_Ls = src.m_Ls;
	
}
CPrsConditionEx::~CPrsConditionEx()
{
	Flush();
}
void CPrsConditionEx::Flush()
{
	std::stack<LogicalNode>	x;
	m_Ls.swap(x);
}
/*
struct ComparisonNode
{
	// ==, !=, <, > ....
	std::shared_ptr<CPrsNode> left;
	std::shared_ptr<CPrsNode> right;
	int operation;
};
struct LogicalNode
{
	// &&, ||
	ComparisonNode left;
	ComparisonNode right;
	int operation;
};
*/
CPrsConditionEx::ComparisonNode CPrsConditionEx::Parse1()
{	
	ComparisonNode cn;
	auto expression = std::make_shared<CPrsExpression>(m_Symbol);
	expression->Parse();
	SToken st = getSymbol();
	cn.left = expression;

	while (st.Token == Equal || st.Token == notEqual || st.Token == LessEqual
		|| st.Token == Less || st.Token == Greater || st.Token == GreaterEqual)
	{
		getNewSymbol();
		expression = std::make_shared<CPrsExpression>(m_Symbol);
		expression->Parse();

		cn.operation = st.Token;
		cn.right = expression;
		
		return cn;

		st = getSymbol();
	}

}
void CPrsConditionEx::Parse()
{
	LogicalNode lnode;
	ComparisonNode cn = Parse1();

	lnode.left = cn;
	SToken st = getSymbol();

	while ( st.Token == ANDAND || st.Token == OROR )
	{
		st = getNewSymbol();
		st = getNewSymbol();
		lnode.operation = st.Token;
		ComparisonNode cn2 = Parse1();
		lnode.right = cn2;

		m_Ls.push(lnode);

		st = getSymbol();
	}

	if (m_Ls.empty())
		m_Ls.push(lnode);

	
	int a = 0;
}

void CPrsConditionEx::Generate(stackGntInfo& stinfo)
{
	LogicalNode ln = m_Ls.top();

	if ( ln.operation == 0 )
	{
		ln.left.left->Generate(stinfo);
		ln.left.right->Generate(stinfo);
		auto r1 = ln.left.left->getValue();
		auto r2 = ln.left.right->getValue();


		switch(ln.left.operation )
		{
			case Equal:
				m_bool = (r1 == r2);
			break;
			case notEqual:
				m_bool = (r1 != r2);
			break;
		}


		return;
	}
	else
		throw(L"���Ή�");

	


	/*std::stack<bool> stk;
	int md = 0;
	for(auto& it : m_Ls)
	{
		if ( it.cnd )
		{	
			it.cnd->Generate(stinfo);
			bool bl = it.cnd->Return();

			stk.push(bl);

			if ( md != 0 )
			{
				bool bl1 = stk.top();
				stk.pop();
				bool bl2 = stk.top();

				if (md == 1)
					stk.push(bl1&&bl2);
				else if ( md == 2 )
					stk.push(bl1||bl2);
				md = 0;
			}
		}
		else if ( it.token == ANDAND )
		{
			md=1;
		}
		else if (it.token == OROR)
		{
			md = 2;
		}

	}
	
	m_bool = stk.top();*/
}