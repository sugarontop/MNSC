#pragma once

#include <string>
#include <map>
#include <vector>
#include <map>

#include <strsafe.h>
#include <atlbase.h>

#include <iostream>
#include <sstream>
#include <stack>
#include <queue>


#define THROW(s)	throw(std::wstring(s))
typedef std::wstring wstring;



#ifdef _DEBUG
#define DEBUG_PARSE(A)	::OutputDebugString(L#A L"\n");
#else
#define DEBUG_PARSE(A)
#endif