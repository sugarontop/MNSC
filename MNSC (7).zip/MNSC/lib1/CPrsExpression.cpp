#include "pch.h"
#include "CPrsNode.h"
#include "FVariantArray.h"

extern wstring gAssign;

class SMethod
{
	public:
		SMethod():Token(0){}

		FVariant value;
		int		Token;
};

////////////////////////////Expression////////////////////////////////////////////////
class CSubTerm
{
	public:
		CSubTerm(CPrsTerm* p, int Token = noToken) { term = p; token = Token; }
		CSubTerm(const CSubTerm& src);
		~CSubTerm() { delete term; }
	public:
		CPrsTerm*	term;
		int			token;
};

CSubTerm::CSubTerm(const CSubTerm& src)
{
	term = nullptr;
	token = src.token;
	if (src.term)
		term = new CPrsTerm(*(src.term));
}
CPrsExpression::CPrsExpression(CPrsSymbol& sym) :CPrsNode(sym)
{
	m_bMinus = FALSE;

	
}
CPrsExpression::CPrsExpression(const CPrsExpression& src) :CPrsNode(src.m_Symbol)
{	
	m_Ls = src.m_Ls;
	m_Value = src.m_Value;
	m_bMinus = src.m_bMinus;
}
CPrsExpression::~CPrsExpression()
{
	Flush();
}
void CPrsExpression::Flush()
{	
	//m_Value.vt = 0;
	
	
	
	m_Ls.clear();

	
	
}
void CPrsExpression::Generate(stackGntInfo& stinfo)
{
	SMethod		sm;
	
	for(auto& it : m_Ls) 
	{
		FVariant value;
		CSubTerm* subterm = it.get();

		if (subterm->term)
		{
			subterm->term->Generate(stinfo);
			value = subterm->term->getValue();
		}

		switch (subterm->token)
		{
			case Plus:
			case Minus:
				sm.Token = subterm->token;
			break;
			case noToken:
			{
				switch (sm.Token)
				{
				case Plus:
					sm.value = sm.value + value;
					break;
				case Minus:
					sm.value = sm.value - value;
					break;
				case noToken:
					sm.value = value;
					break;
				}
			}
			break;
		}
	}

	m_Value = sm.value;

	if ( m_bMinus )
	{
		if (m_Value.VT() == VT_I8)
			m_Value.setN(-m_Value.getN());
		else if (m_Value.VT() == VT_R8)
			m_Value.setD(-m_Value.getD());
		else if (m_Value.VT() == VT_BSTR)
			m_Value.setD(-m_Value.getD());
	}


	if ( next_ )
	{
		auto func = dynamic_cast<CPrsFactor*>(next_.get());

		if ( func )
		{
			func->SetToken(IdentVarFunc, m_Value);
			func->Generate(stinfo);

			// �֐��|�C���^		
			m_Value = func->getValue();
		}
		else
		{
			auto func2 = dynamic_cast<CPrsVarFunction*>(next_.get());

			if ( func2 )
			{
				func2->setgetValue(m_Value);
				func2->Generate(stinfo);
				m_Value = func2->Return();
			}
		}


	}
}
void CPrsExpression::Parse()
{
	DEBUG_PARSE(CPrsExpression)
	if (getSymbol().Token == Minus)
	{
		m_bMinus = true;
		getNewSymbol();
	}

	// term
	CPrsTerm* term = new CPrsTerm(m_Symbol);
	term->Parse();

	m_Ls.push_back(std::make_shared<CSubTerm>(term));

	auto st = getSymbol();

	while (st.Token == Plus || st.Token == Minus)
	{
		m_Ls.push_back(std::make_shared<CSubTerm>(nullptr, st.Token));

		// term()
		getNewSymbol();
		term = new CPrsTerm(m_Symbol);
		term->Parse();

		m_Ls.push_back(std::make_shared<CSubTerm>(term));
		st = getSymbol();
	}

	

}
/////////////////////////////////Trem///////////////////////////////////////////////////////
class CSubFactor
{
public:
	CSubFactor(CPrsFactor* p, int Token = noToken) { factor = p; token = Token; }
	CSubFactor(const CSubFactor& src)
	{
		factor = nullptr;
		token = src.token;
		if (src.factor)
			factor = new CPrsFactor(*(src.factor));

	}
	~CSubFactor()
	{
		delete factor;
	}
public:
	CPrsFactor* factor;
	int			token;
};

CPrsTerm::CPrsTerm(CPrsSymbol& sym) :CPrsNode(sym)
{

}
CPrsTerm::CPrsTerm(const CPrsTerm& src) :CPrsNode(src.m_Symbol)
{
	m_Value = src.m_Value;
	m_Ls = src.m_Ls;
}
CPrsTerm::~CPrsTerm()
{
	Flush();
}

void CPrsTerm::Flush()
{
	m_Ls.clear();
}
void CPrsTerm::Generate(stackGntInfo& stinfo)
{
	SMethod		sm;

	for(auto& it : m_Ls)
	{
		FVariant value;
		CSubFactor* subfactor = it.get();

		if (subfactor->factor)
		{
			subfactor->factor->Generate(stinfo);
			value = subfactor->factor->getValue();
		}


		switch (subfactor->token)
		{
			case Times:
			case Slash:
			case Percent:
				sm.Token = subfactor->token;
				break;
			case noToken:
			{
				switch (sm.Token)
				{
				case Times:
					sm.value = sm.value * value;
					break;
				case Slash:
					sm.value = sm.value / value;
					break;
				case Percent:
					sm.value = sm.value % value;
					break;
				case noToken:
					sm.value = value;
					break;
				}
			}
			break;
		}
	}

	m_Value = sm.value;
}
void CPrsTerm::Parse()
{
	DEBUG_PARSE(CPrsTerm)

	// factor
	CPrsFactor* factor = new CPrsFactor(m_Symbol);
	factor->Parse();

	m_Ls.push_back(std::make_shared<CSubFactor>(factor));

	SToken	st = getSymbol();

	while (st.Token == Times || st.Token == Slash || st.Token == Percent)
	{
		int TokenMethod = st.Token;
		
		m_Ls.push_back(std::make_shared<CSubFactor>(nullptr, TokenMethod));

		// factor
		st = getNewSymbol();
		factor = new CPrsFactor(m_Symbol);
		factor->Parse();

		m_Ls.push_back(std::make_shared<CSubFactor>(factor));

		st = getSymbol();
	}
}

//////////////////////Factor////////////////////////////////////////////////////////////

CPrsFactor::CPrsFactor(CPrsSymbol& sym) :CPrsNode(sym)
{
	m_Token = 0;
	//::VariantInit(&m_Value);
}
CPrsFactor::CPrsFactor(const CPrsFactor& src) :CPrsNode(src.m_Symbol)
{	
	m_Value = src.m_Value;
	m_IdentName = src.m_IdentName;
	m_Token = src.m_Token;
	m_dot_next = src.m_dot_next;

	m_node = factory(src.m_node.get(), m_Token);
}
CPrsFactor::~CPrsFactor()
{
	//m_Value.clear();
	
	Flush();
}

void CPrsFactor::Flush()
{
	m_node = nullptr;
	m_dot_next = nullptr;
	//::VariantClear(&m_Value);
}

void CPrsFactor::Parse()
{
	DEBUG_PARSE(CPrsFactor)

	SToken			st = getSymbol();
	
	if (gAssign == L"c")
	{
		int a = 0;
	}
	if (gAssign == L"b")
	{
		int a = 0;
	}

	m_Token = st.Token;

	auto& localtbl = m_Symbol.getSymbolTable();
	bool bfunction_pointer = false;


	switch (m_Token)
	{
		case Ident:
		{
			auto nst = m_Symbol.getNewPeekSymbol();
			bool IsGlobal = !localtbl.IsContain(st.Value);
			bfunction_pointer = ((nst.Token == Semicol || nst.Token == rSquare || nst.Token == rParen || nst.Token == Comma) && IsGlobal);
			if (bfunction_pointer)
			{
				ParseFunctionPointer(st);
			}
			else if ( nst.Token == lParen )
			{
				ParseIdent(st);
			}
			
			m_IdentName = st.Value;
		}
		break;
		case Number:
		{
			__int64	value;
			ParseNumber(st, value);
			m_Value.setN(value);
			

		}
		break;
		case Float:
			m_Value.setD(_tstof(st.Value.c_str()));
			
		break;
		
		case lParen:
		{
			ParselParen(st);

			auto st2 = getSymbol();
			if (st2.Token == Dot)
			{				
				getNewSymbol();
				m_dot_next = std::make_shared<CPrsVarFunction>(m_Symbol);
				m_dot_next->Parse();
				return;
			}


		}
		break;
		case Quotation:
			m_Value.setS(st.Value);
		break;
		case Plusplus:
		{
			//ex. a++ 
			auto pre = this->m_Symbol.getPreSymbol();
			m_IdentName = pre.Value;
		}
		break;
		case lSquare:
			// making FVariantArray
			ParselSquare(st);
		break;	
		case lBracket:
			// making FVariantMap
			ParselBracket(st);

		break;

		default:
		{
			WCHAR cb[256];
			StringCbPrintf(cb,_countof(cb), L"CPrsFactor::Parse() err:%d %s", m_Token, st.Value.c_str());
			THROW(cb);
		}
		break;
	}

	st = getSymbol();
	if ( st.Token != Semicol )
		st = getNewSymbol();

	if (m_Token == Ident )
	{
		if (st.Token == Dot)
		{
			getNewSymbol();
			m_Token = IdentVarFunc;
			ParseVarFunction(st);
		}
		else if (st.Token == lParen)
		{			
			m_Token = IdentVarFunc;
			ParseVarFunction(st);
		}
		else if (st.Token == lSquare)
		{
			m_Token = IdentArray;
			ParseIdentSquare(st);
		}
		else if (st.Token == lBracket)
		{
			m_Token = IdentVarDic;
			ParseVarFunction(st);
		}

		else if (bfunction_pointer)
		{
			//getNewSymbol();
			m_Token = funcPointerSym;
					
			m_node = factory(nullptr, funcPointerSym);
			m_node->Parse();
		}
	}

	auto st2 = getSymbol();

	if (st2.Token == rParen)
	{
		st2 = m_Symbol.getNewPeekSymbol();
		/*if (st2.Token == Dot)
		{
			getNewSymbol();
			m_dot_next = std::make_shared<CPrsVarFunction>(m_Symbol);
			m_dot_next->Parse();
			
			return;
		}*/

	}
	else if (st2.Token == Dot)
	{
		
		// .�͂Q�܂�
		{
			getNewSymbol();
			auto next = std::make_shared<CPrsVarFunction>(m_Symbol);
			next->Parse();
			m_dot_next = next;

			st2 = getSymbol();

			if (st2.Token == Dot)
			{
				getNewSymbol();
				auto next2 = std::make_shared<CPrsVarFunction>(m_Symbol);
				next2->Parse();
				next->next_ = next2;
			}

		}
		return;
	}
	/*else if (st2.Token == rSquare)
	{
		st2 = m_Symbol.getNewPeekSymbol();
		if (st2.Token == lParen)
		{
			getNewSymbol();
			
			auto next = std::make_shared<CPrsVarFunction>(m_Symbol);
			next->Parse();
			m_dot_next = next;

			return;
		}
	}*/

	
}
void CPrsFactor::ParseVarPoint(SToken& st)
{
	ATLASSERT(m_Token == IdentVarPoint);

	
}
void CPrsFactor::ParseVarFunction(SToken& st)
{
	m_node = factory(nullptr, m_Token);
	m_node->Parse();
}
void CPrsFactor::ParseIdentSquare(SToken& st)
{
	m_node = factory(nullptr, m_Token);
	m_node->Parse();

}
void CPrsFactor::ParselSquare(const SToken& st)
{
	SToken st2;
	
	st2 = getNewSymbol();
	if (st2.Token != rSquare)
	{
		auto nd = factory(nullptr, m_Token);
		nd->Parse();

		m_node = nd;
		auto pre = nd; 

		st2 = getSymbol();
		while (st2.Token == Comma)
		{
			getNewSymbol();

			nd = factory(nullptr, m_Token);				
			nd->Parse();

			CPrsExpression* pre2 = dynamic_cast<CPrsExpression*>(pre.get());
			_ASSERT(pre2);
			pre2->next_ = nd;

			pre = nd;
			st2 = getSymbol();
		}
	}
	
	st2 = getSymbol();
	if (st2.Token != rSquare)
		THROW(L", ERROR");
}
void CPrsFactor::ParselBracket(const SToken& st)
{
	// { "key": 1, "key2" : 2 ... };

	SToken st2;

	st2 = getNewSymbol();
	if (st2.Token != rBracket)
	{
		wstring key = st2.Value;

		st2 = getNewSymbol();
		if (st2.Token != Colon )
			THROW(L"map key : error");

		getNewSymbol();
		auto nd = factory(nullptr, m_Token);
		nd->Parse();

		CPrsExpression* nd2 = dynamic_cast<CPrsExpression*>(nd.get());
		nd2->m_Value.setS(key);

		m_node = nd;
		auto pre = nd2;

		st2 = getSymbol();
		while (st2.Token == Comma)
		{
			st2 = getNewSymbol();
			key = st2.Value;
			st2 = getNewSymbol();
			if (st2.Token != Colon)
				THROW(L"map key : error");

			getNewSymbol();
			nd = factory(nullptr, m_Token);
			nd->Parse();

			CPrsExpression* nd21 = dynamic_cast<CPrsExpression*>(nd.get());
			_ASSERT(nd21);
			nd21->m_Value.setS(key);
			pre->next_ = nd;

			pre = nd21;
			st2 = getSymbol();
		}
	}

	st2 = getSymbol();
	if (st2.Token != rBracket)
		THROW(L", ERROR");
}
void CPrsFactor::ParselParen(SToken& st)
{
	getNewSymbol();
	m_node = factory(nullptr, m_Token);//new CPrsExpression( symbol );
	m_node->Parse();
	auto st2 = getSymbol();
}
void CPrsFactor::TestParseFunctionPointer()
{
	//getNewSymbol();
	m_node = factory(nullptr, ParameterSym);
	m_node->Parse();
	auto st2 = getSymbol();


}
void CPrsFactor::ParseFunctionPointer(SToken& st)
{
	int type = 0;

	// �O���[�o���ϐ�
	CSymbolTable& globalsymtbl = m_Symbol.getGlobalSymbolTable();
	if (globalsymtbl.findTable(st.Value, type))
	{
		if (type == CSymbolTable::TYPE_FUNC)
		{
			st.Token = funcPointerSym;
		}
	}
	else
		THROW(L"function pointer error");

}
int CPrsFactor::ParseIdent(SToken& st)
{
	int type = 0;

	// �O���[�o���ϐ�
	CSymbolTable& globalsymtbl = m_Symbol.getGlobalSymbolTable();
	BOOL found_global = globalsymtbl.findTable(st.Value, type);
	if (found_global)
	{
		if (type == CSymbolTable::TYPE_FUNC)
		{
			m_Token = IdentFunc;
			int typ = ParseIdentFunc(st);	
			return typ;
		}
		else if (type == CSymbolTable::TYPE_BUILTIN_FUNC)
		{
			m_Token = BuiltinFunc;
			ParseBuiltinFunc(st);

		}


		else if (type == CSymbolTable::TYPE_EXPORT)
		{
			_ASSERT(FALSE);
			//m_Token = IdentExport;
			//ParseIdentExport( st );
		}
		else if (type == CSymbolTable::TYPE_LONG)
		{
			// do nothing
		}
		
		
	}	


	// ���[�J���ϐ�
	CSymbolTable& localsymtbl = m_Symbol.getSymbolTable();
	BOOL found_local = localsymtbl.findTable(st.Value, type);
	if (found_local)
	{
		if (type == CSymbolTable::TYPE_LONG)
		{
			// do nothing
		}
		else if (type == CSymbolTable::TYPE_FUNC)
		{
			m_Token = IdentFunc;
			int typ = ParseIdentFunc(st);
			//if (typ == 2)
			//{
			//	// function pointer
			//	m_Token = IdentFunc;
			//	return 2;
			//}

		}
	}	


	if (!found_global && !found_local)
	{
		wstring err = L"not def:";
		err += st.Value;		
		throw(err);
	}
	return 0;
}
void CPrsFactor::ParseNumber(SToken& st, __int64& outValue)
{
	outValue = _tstoi64(st.Value.c_str());
}
int CPrsFactor::ParseIdentFunc(SToken& st)
{
	auto funcName = st.Value;

	auto nst = m_Symbol.getNewPeekSymbol(); //getNewSymbol();

	if ( nst.Token == lParen)
	{
		getNewSymbol();
		m_node = factory(nullptr, m_Token); //new CPrsParameters( symbol );
		m_node->Parse();
	}
	return 0;
}
int CPrsFactor::ParseBuiltinFunc(SToken& st)
{
	auto funcName = st.Value;

	auto nst = m_Symbol.getNewPeekSymbol(); //getNewSymbol();

	if (nst.Token == lParen)
	{
		//getNewSymbol();
		m_node = factory(nullptr, m_Token);
		m_node->Parse();
	}
	return 0;
}

void CPrsFactor::Generate(stackGntInfo& stinfo)
{
	CSymbolTable& symtbl = m_Symbol.getSymbolTable();
	CSymbolTable& symtblG = m_Symbol.getGlobalSymbolTable();
	switch (m_Token)
	{
		case Ident:
		case IdentVarFunc:
		{
			FVariant vSelf;
			

			if (!m_IdentName.empty())
			{
				if (0 != symtbl.getAt(m_IdentName, vSelf))
				{
					if (0 != symtblG.getAt(m_IdentName, vSelf))
					{
						wstring err = L"not def Idnet in Generate: ";
						err += m_IdentName;
						throw(err);
					}
				}
			}
			else
				vSelf = m_Value;

			if (m_node)
			{
				CPrsVarFunction* varfunc =  dynamic_cast<CPrsVarFunction*>(m_node.get());
			
				if ( varfunc )
				{
					FVariant temp(vSelf);
					varfunc->setgetValue(temp);
					varfunc->Generate(stinfo); // var�̊֐�
					m_Value = varfunc->Return();
				}
				else if (dynamic_cast<CPrsParameters*>(m_node.get()) && vSelf.vt == VT_UNKNOWN)
				{
					// a[0](); ��()�����̎��s
					auto prmfunc = dynamic_cast<CPrsParameters*>(m_node.get());
					prmfunc->Generate(stinfo);
				
					auto vfunc = dynamic_cast<IVARIANTAbstract*>(vSelf.punkVal);
					if (FVariantType::FUNCTIONPOINTER == vfunc->TypeId() )
					{
						auto& ar = prmfunc->getParam();

						auto v = std::make_shared<FVariant[]>(ar.size());
						int i = 0;
						for(auto& it : ar )
						{
							v[i++] = it;
						}

						m_Value = vfunc->Invoke(L"NONAME", (VARIANT*)&v[0], (int)ar.size());
					}
				}
				else
					THROW(L"CPrsFactor::Generate error");

			}
			else
			{
				if ( vSelf.vt == VTF_FUNC)
				{	
					auto funcnm = m_IdentName;
					auto ifunc = new IVARIANTFunctionImp();					
					auto func = m_Symbol.CreateFunc(funcnm);
					func->Generate(stinfo);
					ifunc->SetItem(func);

					//::VariantClear(&m_Value);
					m_Value.clear_init();

					m_Value.vt = VT_UNKNOWN;
					m_Value.punkVal = ifunc;
				}
				else
					m_Value = vSelf;
			}


			//::VariantClear(&vSelf);
		}
		break;
	
		case Float:
		case Quotation:
		case Number:
			//TRACE( "%s\n", (LPCTSTR)m_IdentName );
		break;
		case lParen:
			if (m_node)
			{
 				m_node->Generate(stinfo);
				_ASSERT(dynamic_cast<CPrsExpression*>(m_node.get()));

				m_Value = dynamic_cast<CPrsExpression*>(m_node.get())->getValue();
			}
		break;
		case IdentFunc:
		{
			if (m_node)
			{
				auto param = std::make_unique<CPrsParameters>(*((CPrsParameters*)m_node.get()));
				auto func = m_Symbol.CreateFunc(m_IdentName);

				param->Generate(stinfo);
				func->SetParameters(*param);
				func->Generate(stinfo);
				m_Value = func->getValue();

			
				func = nullptr;
			}
		}
		break;
		case BuiltinFunc:
		{
			m_node->Generate(stinfo);

			m_Value = ((CPrsBuiltinFunction*)m_node.get())->Return();
		}
		break;


		case Plusplus:
		{
			FVariant var;
			if (0 != symtbl.getAt(m_IdentName, var))
			{
				if (0 != symtblG.getAt(m_IdentName, var))
				{
					wstring err = L"not def Idnet in Generate: ";
					err += m_IdentName;
					throw(err);
				}
			}

			var.llVal += 1;
			m_Value = var;
		}
		break;
		case lSquare:
		{
			// generate FVariantArray, 
			std::vector<FVariant> data;

			auto it = m_node;
			while(true) 
			{
				it->Generate(stinfo);
				CPrsExpression* exp = (CPrsExpression*)it.get();
				data.push_back(exp->getValue());

				if (exp->next_)
					it = exp->next_;
				else
					break;
			}
			m_Value.setAr(data);
		}
		break;
		case funcPointerSym:
		{
			m_node->Generate(stinfo);
		
			CPrsIdentFunctionPointer* x = (CPrsIdentFunctionPointer*)m_node.get();

			m_Value = x->Value();
		}
		break;
		case lBracket:
		{
			// generate FVariantMap
			std::map<wstring,FVariant> map;

			auto it = m_node;
			while (true)
			{
				CPrsExpression* exp = (CPrsExpression*)it.get(); 

				if ( exp )
				{
					FVariant key;
					key = exp->getValue(); //>m_Value;

					if ( key.vt = VT_BSTR && key.bstrVal )
					{
						exp->Generate(stinfo);			
						map[key.getSS()] = exp->getValue();
					}	

					if (exp->next_)
						it = exp->next_;
					else
						break;
				}
				else
					break;
			}
			m_Value.setMap(map);
		}
		break;
		case IdentArray:
		{
			m_node->Generate(stinfo);
			FVariant idx = ((CPrsIdentArray*)m_node.get())->Value();

			FVariant var;
			if (0 != symtbl.getAt(m_IdentName, var))
			{
				if (0 != symtblG.getAt(m_IdentName, var))
				{
					wstring err = L"not def Idnet in Generate: " + m_IdentName;				
					throw(err);
				}
			}

			if ( var.vt == VT_EMPTY )
			{
				std::wstring s = L"IdentArray err: " + m_IdentName;
				throw(s);
			}

			if (var.vt == VT_UNKNOWN )
			{
				IVARIANTArray* x = (IVARIANTArray*)var.punkVal;

				if ( x->TypeId() == FVariantType::ARRAY)
				{
					VARIANT v;
					::VariantInit(&v);

					x->Get((int)idx.llVal, &v);

					m_Value = v;

					

				}
				else if (x->TypeId() == FVariantType::MAP)
				{
					IVARIANTMap* m = (IVARIANTMap*)var.punkVal;

					_ASSERT(idx.vt == VT_BSTR);
					wstring key = idx.bstrVal;

					VARIANT v;
					::VariantInit(&v);
					m->GetItem(key, &v);

					m_Value = v;
				}
				else
					THROW(L"Generate Square err");
			}
			else if ( var.vt == VT_BSTR)
			{
				BSTR s = var.bstrVal;
				ULONG len = ::SysStringLen(s);

				if ( idx.llVal < len )
				{
					WCHAR cb[2]={};
					cb[0] = s[idx.llVal];
					m_Value.setS(cb);
				}
				else
					THROW(L"string pos is over");
			}
			else
				THROW(L"VT is invalid");
		}
		break;
	}



	
	if ( m_dot_next )
	{
		CPrsVarFunction* pf = (CPrsVarFunction*)m_dot_next.get();
		pf->setgetValue(m_Value);
		pf->Generate(stinfo);
		m_Value = pf->Return();
	}
}

std::shared_ptr<CPrsNode> CPrsFactor::factory(CPrsNode* src, int type, LPCTSTR funcName)
{
	std::shared_ptr<CPrsNode> node;
	switch (type)
	{
		case IdentFunc:
		case IdentExport:
			if (src)
				node = std::make_shared<CPrsParameters>(*(CPrsParameters*)src);
			else
				node = std::make_shared<CPrsParameters>(m_Symbol);
		break;
		case lParen:	// (
		case lBracket:	// {
		case lSquare:	// [
			if (src)
				node = std::make_shared<CPrsExpression>(*(CPrsExpression*)src);
			else
				node = std::make_shared<CPrsExpression>(m_Symbol);
		break;
		case IdentVarFunc:
			if (src)
				node = std::make_shared <CPrsVarFunction>(*(CPrsVarFunction*)src);
			else
				node = std::make_shared <CPrsVarFunction>(m_Symbol);
		break;
		case IdentArray:		
			if (src)
				node = std::make_shared <CPrsIdentArray>(*(CPrsIdentArray*)src);
			else
				node = std::make_shared <CPrsIdentArray>(m_Symbol);
		break;
		case funcPointerSym:
			if (src)
				node = std::make_shared <CPrsIdentFunctionPointer>(*(CPrsIdentFunctionPointer*)src);
			else
				node = std::make_shared <CPrsIdentFunctionPointer>(m_Symbol);
		break;
		case BuiltinFunc:
			if (src)
				node = std::make_shared <CPrsBuiltinFunction>(*(CPrsBuiltinFunction*)src);
			else
				node = std::make_shared <CPrsBuiltinFunction>(m_Symbol);

		break; 
		case ParameterSym:
			if (src)
				node = std::make_shared <CPrsParameters>(*(CPrsParameters*)src);
			else
				node = std::make_shared <CPrsParameters>(m_Symbol);
		break;
	}
	return node;
}
