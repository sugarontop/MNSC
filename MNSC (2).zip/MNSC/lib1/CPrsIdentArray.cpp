#include "pch.h"
#include "CPrsNode.h"
#include "FVariantArray.h"

///////////////////////////////////////////////////////////////////////////////////
CPrsIdentArray::CPrsIdentArray(CPrsSymbol& sym) :CPrsNode(sym)
{

}
CPrsIdentArray::CPrsIdentArray(const CPrsIdentArray& src) :CPrsNode(src.m_Symbol)
{
	Return_ = src.Return_;
	expression_ = src.expression_;
}
CPrsIdentArray::~CPrsIdentArray()
{
	Flush();
}
void CPrsIdentArray::Flush()
{
	expression_ = nullptr;

}
void CPrsIdentArray::Parse()
{
	auto stpre = m_Symbol.getPreSymbol();
	auto st = this->getSymbol();
	if ( st.Token == lSquare )
	{
		st = this->getNewSymbol();
		// key 
		expression_ = std::make_shared<CPrsExpression>(m_Symbol);
		expression_->Parse();
	}

	st = getSymbol(); // a[0] rSquare�̌��͐F�X����

	if ( st.Token == rSquare)
	{
		st = getNewSymbol();

		/*if (st.Token == Dot)
		{
			getNewSymbol();
			auto prm = std::make_shared<CPrsVarFunction>(m_Symbol);
			prm->Parse();
			expression_->next_ = prm;
		}*/

	}


	//if ( st.Token != Semicol && st.Token != rParen)
	//	THROW(L"; error");
}
void CPrsIdentArray::Generate(stackGntInfo& stinfo)
{
	expression_->Generate(stinfo);
	Return_ = expression_->getValue();

}

///------------------------------------------
CPrsIdentFunctionPointer::CPrsIdentFunctionPointer(CPrsSymbol& sym) :CPrsNode(sym)
{

}
CPrsIdentFunctionPointer::CPrsIdentFunctionPointer(const CPrsIdentFunctionPointer& src) :CPrsNode(src.m_Symbol)
{
	Return_ = src.Return_;
}
CPrsIdentFunctionPointer::~CPrsIdentFunctionPointer()
{
	Flush();
}
void CPrsIdentFunctionPointer::Flush()
{

}
void CPrsIdentFunctionPointer::Parse()
{
	auto stpre = m_Symbol.getPreSymbol();
	auto st = this->getSymbol();
	funcnm_ = stpre.Value;

}
void CPrsIdentFunctionPointer::Generate(stackGntInfo& stinfo)
{
	auto x = new IVARIANTFunctionImp(); // FVariant�Ɉړ����邱��

	auto func = m_Symbol.CreateFunc(funcnm_);
	x->SetItem(func);

	Return_.vt = VT_UNKNOWN;
	Return_.punkVal = x;
}