#include "pch.h"
#include "CPrsNode.h"


//////////////////////////////////////////////////////////////////////////////////////////////////
CPrsConditionEx::CPrsConditionEx(CPrsSymbol& sym) :CPrsNode(sym), m_bool(false)
{

}
CPrsConditionEx::CPrsConditionEx(const CPrsConditionEx& src) :CPrsNode(src.m_Symbol)
{
	m_bool = src.m_bool;
	m_Ls = src.m_Ls;
	
}
CPrsConditionEx::~CPrsConditionEx()
{
	Flush();
}
void CPrsConditionEx::Flush()
{
	std::stack<ComparisonNode>	x;
	m_Ls.swap(x);
}
CPrsConditionEx::ComparisonNode CPrsConditionEx::Parse1()
{	
	ComparisonNode cn;
	auto expression = std::make_shared<CPrsExpression>(m_Symbol);
	expression->Parse();
	SToken st = getSymbol();
	cn.left = expression;

	if (st.Token == Equal || st.Token == notEqual || st.Token == LessEqual
		|| st.Token == Less || st.Token == Greater || st.Token == GreaterEqual)
	{
		getNewSymbol();
		expression = std::make_shared<CPrsExpression>(m_Symbol);
		expression->Parse();

		cn.operation = st.Token;
		cn.right = expression;			
	}
	return cn;
}
void CPrsConditionEx::Parse()
{
	ComparisonNode cn = Parse1();
	m_Ls.push(cn);

	SToken st = getSymbol();

	if ( st.Token == rParen && 0 != m_Symbol.getParenNumber())
		st = getNewSymbol();

	while ( st.Token == ANDAND || st.Token == OROR )
	{
		int header = st.Token;
		st = getNewSymbol();		
		ComparisonNode cn2 = Parse1();
		cn2.header = header;

		m_Ls.push(cn2);

		st = getSymbol();

		
		if (st.Token == rParen)
		{
			if ( 0 == m_Symbol.getParenNumber())
				break;

			st = getNewSymbol();
		}
	}
}

void CPrsConditionEx::Generate(stackGntInfo& stinfo)
{
	struct X
	{
		X(bool b,int h):bl(b),header(h){}
		bool bl;
		int header;
	};

	std::stack<ComparisonNode>	cnds(m_Ls);
	std::queue<X> st;

	while(!cnds.empty())
	{
		auto a1 = cnds.top();

		a1.left->Generate(stinfo);
		a1.right->Generate(stinfo);
		auto r1 = a1.left->getValue();
		auto r2 = a1.right->getValue();

		X x(false,0);
		x.header = a1.header;
		switch(a1.operation )
		{
			case Equal:
				x.bl = (r1 == r2);
			break;
			case notEqual:
				x.bl = (r1 != r2);
			break;
			case LessEqual:
				x.bl = (r1 <= r2);
			break;
			case GreaterEqual:
				x.bl = (r1 >= r2);
			break;
			case Less:
				x.bl = (r1 < r2);
			break;
			case Greater:
				x.bl = (r1 > r2);
			break;
		}

		st.push(x);
		cnds.pop();
	}

	while(st.size() > 1)
	{
		std::queue<X> st2;
		while(!st.empty())
		{
			X x = st.front();

			if (x.header == ANDAND)
			{
				st.pop();
				X x2 = st.front();

				X nx((x.bl&& x2.bl), x2.header);
				st2.push(nx);
			}
			else if (x.header == OROR)
			{
				st.pop();
				X x2 = st.front();

				X nx((x.bl|| x2.bl), x2.header);
				st2.push(nx);
			}
			else
				st2.push(x);

			st.pop();
		}
		st.swap(st2);
	}
	m_bool = st.front().bl;
}