#pragma once

#include <memory>
#include <vector>
#include <map>

#define VTF_FUNC			(VT_RESERVED+1)
#define VTF_BUILTIN_FUNC	(VT_RESERVED+2)

enum FVariantType {ARRAY=1,MAP=2, FUNCTIONPOINTER =3};

class FVariant : private tagVARIANT
{	
	public :
		using tagVARIANT::vt;
		using tagVARIANT::bstrVal;
		using tagVARIANT::intVal;
		using tagVARIANT::iVal;
		using tagVARIANT::punkVal;
		using tagVARIANT::dblVal;
		using tagVARIANT::llVal;
		using tagVARIANT::boolVal;

	public:
		FVariant() { init(); }
		FVariant(const FVariant& var);
		FVariant(VARIANT v);
		
		explicit FVariant(LPCWSTR str);
		explicit FVariant(__int64 x);
		explicit FVariant(double x);
		explicit FVariant(int x);
		explicit FVariant(bool x);
		
		~FVariant() { clear(); }

		void InnerCopy(const VARIANT* src);
	public:
		enum { DIGIT = 100, DIGITX = 2 };

		void init();
		void clear();
		void detach();
		inline void clear_init();
		//void setDL(__int64 value) { flush(); vt = VTF_DOLLAR; data.iVal = value; }
		void setN(__int64 value) {  vt = VT_I8; llVal = value; }
		void setD(double value) {  vt = VT_R8; dblVal = value; }
		void setS(const TCHAR* str) {  vt = VT_BSTR; bstrVal = ::SysAllocString(str); }
		void setS(const std::wstring& str) {  vt = VT_BSTR; bstrVal = ::SysAllocString(str.c_str()); }
		void setBSTR(BSTR str) {  vt = VT_BSTR; bstrVal = ::SysAllocString(str); }
		void setBL(bool x) { vt = VT_BOOL; boolVal = (x ? -1 : 0);}

		//void setVARIANT(const VARIANT v){  ::VariantCopy(this,&v); }

	//	void setF(const TCHAR* str) { setS(str); vt = VTF_FUNC; }
	//	void setE(const TCHAR* str) { setS(str); vt = VTF_EXPORT; }
	//	void setED(const TCHAR* str) { setS(str); vt = VTF_EXPORTDATA; }
	//	void setO(const TCHAR* str) { setS(str); vt = VTF_OBJECT; }

		void setAr(const std::vector<FVariant>& ar);
		void set(const FVariant& var);
		void setAr(const FVariant& key, const FVariant& var);
		FVariant getAr(int idx) const;

		void setMap(std::map<wstring, FVariant>& map);

		//void setArAdd(const FVariant& var);
		void setUnknown(const FVariant& var);
	//	void setAr(const arFVariant& ar);
		//void setAr(int cnt);

	
		void setDic(const FVariant& key, const FVariant& val);
		bool getDic(const FVariant& key, FVariant* ret) const;
	
		VARTYPE VT() const { return this->vt; }

		__int64	getN() const;

		double	getD() const;
		const BSTR	getS() const { return bstrVal; }
		bool getBL() const ;
	/*	
		FSTD::string	getF() const { return m_cVal; }
		FSTD::string	getE() const { return m_cVal; }
		FSTD::string	getED() const { return m_cVal; }
		FSTD::string	getO() const { return m_cVal; }
	*/
		VARIANT ToVARIANT() const;
		void ToCopy(VARIANT* dst) const;
		void FromCopy(const VARIANT* src);
		const BSTR getSS() const { return bstrVal; }

		ULONG	length() const;

		void	toStr();
	/*
		void	toNumber();
	
		void	toUpper();
		void	toLower();
		void	toPerEncode();
		void	toNumberEx(int type);
		void	toFloat();
		void	toDoller();
		void	DollRound();
		FVariant	substr(int pos, int len);
		BOOL	find(LPCTSTR findstr);
		long	match(LPCTSTR findstr);
	*/
	private :
	
	public:
		const FVariant& operator = (const FVariant& v);
		const FVariant& operator = (const VARIANT& v);
	
		

		FVariant& operator += (const FVariant& v);
		FVariant& operator += (const LPCTSTR str);
		friend FVariant operator + (const FVariant& var1, const FVariant& var2);
		friend FVariant operator - (const FVariant& var1, const FVariant& var2);
		friend FVariant operator * (const FVariant& var1, const FVariant& var2);
		friend FVariant operator / (const FVariant& var1, const FVariant& var2);
		friend FVariant operator % (const FVariant& var1, const FVariant& var2);

		friend FVariant operator || (const FVariant& var1, const FVariant& var2);
		friend FVariant operator && (const FVariant& var1, const FVariant& var2);

		BOOL operator > (const FVariant&) const;
		BOOL operator < (const FVariant&) const;
		BOOL operator == (const FVariant&) const;
		BOOL operator != (const FVariant&) const;
		BOOL operator >= (const FVariant&) const;
		BOOL operator <= (const FVariant&) const;

};