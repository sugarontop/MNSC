#pragma once

#include <string>
#include <map>
#include <vector>
#include <map>

#include <strsafe.h>
#include <atlbase.h>

#include <iostream>
#include <sstream>
#include <stack>
#include <queue>


#define THROW(s)	throw(std::wstring(s))
typedef std::wstring wstring;