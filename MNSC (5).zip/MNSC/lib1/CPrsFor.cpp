#include "pch.h"
#include "CPrsNode.h"

CPrsFor::CPrsFor(CPrsSymbol& sym) :CPrsNode(sym)
{

}
CPrsFor::CPrsFor(const CPrsFor& src) :CPrsNode(src.m_Symbol)
{
	m_condition = src.m_condition;
	m_statementlist = src.m_statementlist;
	m_ini_assign = src.m_ini_assign;
	m_icr_assign = src.m_icr_assign;

}
CPrsFor::~CPrsFor()
{
	Flush();
}

void CPrsFor::Flush()
{
	m_condition = nullptr;
	m_statementlist = nullptr;
	m_ini_assign = nullptr;
	m_icr_assign = nullptr;

}

void CPrsFor::Generate(stackGntInfo& stinfo)
{
	if (m_condition)
	{
		m_ini_assign->Generate(stinfo);
		m_condition->Generate(stinfo);
		while (m_condition->enableProcess())
		{
			if (m_statementlist)
			{
				// statementlist����break�������悤�ɐݒ�


				stinfo.top().m_stackInfo.push(CPrsGntInfo::in_loop);

				m_statementlist->Generate(stinfo);

				int brk = stinfo.top().m_stackInfo.top();

				stinfo.top().m_stackInfo.pop();

				if (brk == CPrsGntInfo::outof_loop)
					break;
			}

			m_icr_assign->Generate(stinfo);
			m_condition->Generate(stinfo);
		}
	}
}
void CPrsFor::Parse()
{
	SToken st = getNewSymbol();

	if (st.Token == lParen)
	{
		getNewSymbol();
		m_ini_assign = std::make_shared<CPrsAssign>(m_Symbol);
		m_ini_assign->Parse();
	}
	else
		THROW(L"'(' expected");

	m_condition = std::make_shared <CPrsCondition>(m_Symbol);
	m_condition->Parse();

	st = getNewSymbol();

	m_icr_assign = std::make_shared <CPrsAssignPlusEqual>(m_Symbol);
	m_icr_assign->Parse();


	if (getSymbol().Token == rParen)
	{
		getNewSymbol();
		m_statementlist = std::make_shared <CPrsStatmentList>(m_Symbol, ENDSYMBOL_ENDNEXT);
		m_statementlist->Parse();
		st = getSymbol();

		if (getSymbol().Token != nextSym)
		{
			THROW(L"'next' expected");
		}

		getNewSymbol();

	}
	else
		THROW(L"')' expected");
}

