#pragma once
typedef VARIANT(*VARIANTFUNC)(const VARIANT, const VARIANT, const VARIANT, const VARIANT);

void VarFunctionInit(std::map<wstring, VARIANTFUNC>& map);