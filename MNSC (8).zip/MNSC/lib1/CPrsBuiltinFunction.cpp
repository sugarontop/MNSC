#include "pch.h"
#include "CPrsNode.h"
#include <random>

CPrsBuiltinFunction::CPrsBuiltinFunction(CPrsSymbol& sym) :CPrsNode(sym)
{

}
CPrsBuiltinFunction::CPrsBuiltinFunction(const CPrsBuiltinFunction& src) :CPrsNode(src.m_Symbol)
{
	m_parameter = src.m_parameter;
	FuncName_ = src.FuncName_;
	Return_ = src.Return_;
}
CPrsBuiltinFunction::~CPrsBuiltinFunction()
{
	m_parameter = nullptr;
}
void CPrsBuiltinFunction::Parse()
{
	auto st = getSymbol();
	FuncName_ = st.Value;

	if (functions_map_.find(FuncName_) == functions_map_.end())
		THROW(L"not found Buildin function");

	st = getNewSymbol();
	_ASSERT( st.Token == lParen );

	m_parameter = std::make_shared<CPrsParameters>(m_Symbol);
	m_parameter->Parse();

	

	st = getSymbol();
	_ASSERT(st.Token == rParen);

}
void CPrsBuiltinFunction::Generate(stackGntInfo& stinfo)
{
	m_parameter->Generate(stinfo);

	auto ar = m_parameter->getParam();
	auto target = functions_map_[FuncName_];
	if ( 0 < ar.size())
	{				
		const FVariant* pv = &ar[0];		
		Return_ = target.func(pv, target.prmcnt);
	}
	else
		Return_ = target.func(nullptr,0);


}
void CPrsBuiltinFunction::Flush()
{
	m_parameter = nullptr;
}
//----------------------------------------------------------

std::map<wstring, CPrsBuiltinFunction::XSt> CPrsBuiltinFunction::functions_map_;

static FVariant f_sin(const FVariant* v, int cnt);
static FVariant f_cos(const FVariant* v, int cnt);
static FVariant f_log(const FVariant* v, int cnt);
static FVariant f_sqrt(const FVariant* v, int cnt);
static FVariant f_vt(const FVariant* v, int cnt);
static FVariant f_sleep(const FVariant* v, int cnt);
static FVariant f_rand(const FVariant* v, int cnt);

#define FUNCTIONS \
{0,L"sin", 1, f_sin}, \
{1,L"cos",1, f_cos}, \
{2,L"log",1, f_log}, \
{3,L"sqrt",1, f_sqrt}, \
{4,L"vt",1, f_vt}, \
{5,L"sleep",1, f_sleep}, \
{6,L"rand",1, f_rand} \

void CPrsBuiltinFunction::Initialize(CSymbolTable& gtable)
{
	XSt f[] = { FUNCTIONS };
	for(auto& it : f)
	{
		functions_map_[it.nm] = it;
		gtable.set( it.nm, CSymbolTable::TYPE_BUILTIN_FUNC);
	}
}




static FVariant f_sin(const FVariant* v, int cnt)
{
	return FVariant(sin(v[0].getD()));
}
static FVariant f_cos(const FVariant* v, int cnt)
{
	return FVariant(cos(v[0].getD()));
}
static FVariant f_log(const FVariant* v, int cnt)
{
	return FVariant(log(v[0].getD()));
}
static FVariant f_sqrt(const FVariant* v, int cnt)
{
	return FVariant(sqrt(v[0].getD()));
}
static FVariant f_vt(const FVariant* v, int cnt)
{
	return FVariant(v[0].vt);
}
static FVariant f_sleep(const FVariant* v, int cnt)
{
	::Sleep(v[0].intVal);
	return FVariant(v[0]);
}
static FVariant f_rand(const FVariant* v, int cnt)
{
	static std::random_device rd; 
	static std::mt19937 gen(rd()); // �����Z���k�E�c�C�X�^ 
	static std::uniform_real_distribution<double> dist(0.0, 1.0);
		
	return FVariant( (double)dist(gen));
}